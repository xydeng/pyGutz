# pyGutz
## Note slightly change might happen now and then due to the code as well as its dependences TRIQS are in active developement.

# to run the code using pytriqs.
## for example.
pytriqs tbGutz.py

## check tbGutz.py as well as testOutforGutz.py for tests
